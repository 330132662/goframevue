// 下面两个值由各自的 .env 文件注入（.env / .env.development / .env.production）
const domain="";//您的域名//独立部署需要填写Go服务api接口域名(部署在Go目录下可以留空)
const localhost="http://localhost:8606";//访问本地的域名和端口，如果您改变Go服务端口，请自行修改
window.globalConfig = {
	Main_url:`${domain}`,//域名
	Main_url_dev:`${localhost}`,//域名
	Root_url:`${domain}/admin`,//Api服务器域名
    Root_url_dev:`${localhost}/admin`,//Api服务器域名-开发环境
	Upload_url:`${domain}/common`,//Api服务器域名
	Upload_url_dev:`${localhost}/common`,//Api服务器域名-开发环境
	AppTitle_zhCN:"GoframePro开发框架",
    AppTitle_zhTW:"GoframePro開發框架",
	AppTitle_enUS:"GoframePro Dev frame",
    CompanySite:"//goflys.cn/",//公司官网
    ICP:"鲁ICP备19001128号-3",//备案号
    Company:"潍坊立师科技有限公司",//公司名称
    Address:"中国·潍坊",
    
    TeamSite:"//goflys.cn/",//技术团队官网
    Team:"GoFly技术团队",//技术团队，没有则填空""
    loginTitle_zhCN:`Go语言开发用<span class="sub-title">GoframePro框架</span>`,
    loginTitle_zhTW:`Go語言開發用<span class="sub-title">GoframePro框架</span>`,
    loginTitle_enUS:`<span class="sub-title">GoframePro</span> framework is used for Go development`,
    loginDesc_zhCN:["开发效率高","基础功能完善","开发文档全面"],
    loginDesc_zhTW:["開發效率高","基礎功能完善","開發文檔全面"],
    loginDesc_enUS:["High development efficiency","Complete basic functions","Comprehensive development documentation"],
    Copyright:"GoFly团队提供技术支持",
    RouterHome:"home",//路由默认入口
    MaxSizeImage:5,//最大上传图片大小,单位M
	MaxSizeVideo:150,//最大上传视频大小,单位M
    DefaultAccountPassword:[],//演示账号密码值为：["admin","admin888"]，正式项目请修改为空数组-即值为：[]
};
